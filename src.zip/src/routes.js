import AnagramCheck from './infografias/AnagramCheck';
import CheckPalindrome from './infografias/CheckPalindrome';
import FindDuplicatesInArray from './infografias/FindDuplicatesInArray';
import FindMinAndMaxInArray from './infografias/FindMinAndMaxInArray';
import ReverseAString from './infografias/ReverseAString';
import StringLength from './infografias/StringLength';
import TwoSumProblem from './infografias/TwoSumProblem';
import RemoveDuplicatesForSortedArray from './infografias/RemoveDuplicatesForSortedArray';
import BubbleSort from './infografias/BubbleSort';
import LinearSearch from './infografias/LinearSearch';
import SimpleSortingInSQL from './infografias/SimpleSortingInSQL';
import FilteringInMongoDB from './infografias/FilteringInMongoDB';
import PrimeNumberCheck from './infografias/PrimeNumberCheck';
import CICDFlowDiagram from './infografias/CICDFlowDiagram';
import PalindromeCheck from './infografias/PalindromeCheck';
import TwoSumCheck from './infografias/TwoSumCheck';
import SlidingWindowCheck from './infografias/SlidingWindowCheck';  
import ArrayAccess from './infografias/ArrayAccess';
import LinkedlistDemo from './infografias/LinkedlistDemo';
import StackParentheses from './infografias/StackParentheses';
import QueueSimulation from './infografias/QueueSimulation';
import CycleDetection from './infografias/CycleDetection';
import SlidingWindowSum from './infografias/SlidingWindowSum';
import RecursionFactorial from './infografias/RecursionFactorial';
import RecursionFibonacci from './infografias/RecursionFibonacci';
import BacktrackingNQueens from './infografias/BacktrackingNQueens';
import BacktrackingPermutations from './infografias/BacktrackingPermutations';
import BinaryTreeTraversal from './infografias/BinaryTreeTraversal';
import DFSPathMaze from './infografias/DFSPathMaze';
import TrieAutocomplete from './infografias/TrieAutocomplete';
import DivideConquerMergeSort from './infografias/DivideConquerMergeSort';
import DivideConquerQuickSort from './infografias/DivideConquerQuickSort';
import HashTableDemo from './infografias/HashTableDemo';
import SetOperations from './infografias/SetOperations';
import HeapDemo from './infografias/HeapDemo';
import PriorityQueueDemo from './infografias/PriorityQueueDemo';
import GraphRepresentation from './infografias/GraphRepresentation';
import GraphDFS from './infografias/GraphDFS';
import GraphBFS from './infografias/GraphBFS';
import GraphDijkstra from './infografias/GraphDijkstra';
import GraphAStar from './infografias/GraphAStar';
import	DPFibonacci	from './infografias/DPFibonacci';
import	DPLCS	from './infografias/DPLCS';
import	DPSubsetSum	from './infografias/DPSubsetSum';
import	DPKnapsack	from './infografias/DPKnapsack';
import	DPCoinChange	from './infografias/DPCoinChange';
import	DPEditDistance	from './infografias/DPEditDistance';
import	DPMatrixChain	from './infografias/DPMatrixChain';
import	DPLIS	from './infografias/DPLIS';
import	DPWordBreak	from './infografias/DPWordBreak';
import AVLTree from './infografias/AVLTree';
import RedBlackTree from './infografias/RedBlackTree';
import SegmentTree from './infografias/SegmentTree';
import FenwickTree from './infografias/FenwickTree';
import DisjointSetUnion from './infografias/DisjointSetUnion';
import TriePrefixCount from './infografias/TriePrefixCount';
import KMPPatternMatching from './infografias/KMPPatternMatching';
import RabinKarp from './infografias/RabinKarp';
import TopologicalSort	from './infografias/TopologicalSort';
import KosarajuSCC	from './infografias/KosarajuSCC';
import TarjanSCC	from './infografias/TarjanSCC';
import BellmanFord	from './infografias/BellmanFord';
import FloydWarshall	from './infografias/FloydWarshall';
import PrimMST	from './infografias/PrimMST';
import KruskalMST	from './infografias/KruskalMST';
import FordFulkerson	from './infografias/FordFulkerson';
import BinarySearchAnswer from './infografias/BinarySearchAnswer';
import MeetInTheMiddle from './infografias/MeetInTheMiddle';
import BitmaskTSP from './infografias/BitmaskTSP';
import HungarianAlgorithm from './infografias/HungarianAlgorithm';
import LinearProgramming2D from './infografias/LinearProgramming2D';
import GeneticAlgorithm from './infografias/GeneticAlgorithm';




const routes = [
  { path: "/Anagram_Check", name: "Anagram Check", component: AnagramCheck },
  { path: "/Check_Palindrome", name: "Check Palindrome", component: CheckPalindrome },
  { path: "/Two_Sum_Check", name: "Two Sum Check", component: TwoSumCheck },
  { path: "/Sliding_Window_Check", name: "Sliding Window Check", component: SlidingWindowCheck },
  { path: "/Array_Access", name: "Array Access", component: ArrayAccess },
  { path: "/Linked_List_Demo", name: "Linked List Demo", component: LinkedlistDemo },
  { path: "/Stack_Parentheses", name: "Stack Parentheses", component: StackParentheses },
  { path: "/Queue_Simulation", name: "Queue Simulation", component: QueueSimulation },
  { path: "/Cycle_Detection", name: "Cycle Detection", component: CycleDetection },
  { path: "/Sliding_Window_Sum", name: "Sliding Window Sum", component: SlidingWindowSum },
  { path: "/Recursion_Factorial", name: "Recursion Factorial", component: RecursionFactorial },
  { path: "/Recursion_Fibonacci", name: "Recursion Fibonacci", component: RecursionFibonacci },
  { path: "/Backtracking_N_Queens", name: "Backtracking N Queens", component: BacktrackingNQueens },
  { path: "/Backtracking_Permutations", name: "Backtracking Permutations", component: BacktrackingPermutations },
  { path: "/Binary_Tree_Traversal", name: "Binary Tree Traversal", component: BinaryTreeTraversal },
  { path: "/DFS_Path_Maze", name: "DFS Path in Maze", component: DFSPathMaze },
  { path: "/Trie_Autocomplete", name: "Trie Autocomplete", component: TrieAutocomplete },
  { path: "/Divide_Conquer_Merge_Sort", name: "Divide & Conquer Merge Sort", component: DivideConquerMergeSort },
  { path: "/Divide_Conquer_Quick_Sort", name: "Divide & Conquer Quick Sort", component: DivideConquerQuickSort },
  { path: "/Hash_Table_Demo", name: "Hash Table Demo", component: HashTableDemo },
  { path: "/Set_Operations", name: "Set Operations", component: SetOperations },
  { path: "/Heap_Demo", name: "Heap Demo", component: HeapDemo },
  { path: "/Priority_Queue_Demo", name: "Priority Queue Demo", component: PriorityQueueDemo },
  { path: "/Graph_Representation", name: "Graph Representation", component: GraphRepresentation },
  { path: "/Graph_DFS", name: "Graph DFS", component: GraphDFS },
  { path: "/Graph_BFS", name: "Graph BFS", component: GraphBFS },
  { path: "/Graph_Dijkstra", name: "Graph Dijkstra", component: GraphDijkstra },
  { path: "/Graph_AStar", name: "Graph A*", component: GraphAStar },
  { path: "/DPFibonacci", name: "Fibonacci", component: DPFibonacci },
  { path: "/DPLCS", name: "Longest Common Subsequence", component: DPLCS },
  { path: "/DPSubsetSum", name: "Subset Sum", component: DPSubsetSum },
  { path: "/DPKnapsack", name: "0/1 Knapsack", component: DPKnapsack },
  { path: "/DPCoinChange", name: "Coin Change", component: DPCoinChange },
  { path: "/DPEditDistance", name: "Edit Distance", component: DPEditDistance },
  { path: "/DPMatrixChain", name: "Matrix Chain Multiplication", component: DPMatrixChain },
  { path: "/DPLIS", name: "Longest Increasing Subsequence", component: DPLIS },
  { path: "/DPWordBreak", name: "Word Break", component: DPWordBreak },
  { path: "/AVL_Tree", name: "AVL Tree", component: AVLTree },
  { path: "/Red_Black_Tree", name: "Red Black Tree", component: RedBlackTree },
  { path: "/Segment_Tree", name: "Segment Tree", component: SegmentTree },
  { path: "/Fenwick_Tree", name: "Fenwick Tree", component: FenwickTree },
  { path: "/Disjoint_Set_Union", name: "Disjoint Set Union", component: DisjointSetUnion },
  { path: "/Trie_Prefix_Count", name: "Trie Prefix Count", component: TriePrefixCount },
  { path: "/KMP_Pattern_Matching", name: "KMP Pattern Matching", component: KMPPatternMatching },
  { path: "/Rabin_Karp", name: "Rabin Karp", component: RabinKarp },
  { path: "/Topological_Sort", name: "Topological Sort", component: TopologicalSort },
  { path: "/Kosaraju_SCC", name: "Kosaraju's Algorithm", component: KosarajuSCC },
  { path: "/Tarjan_SCC", name: "Tarjan's Algorithm", component: TarjanSCC },
  { path: "/Bellman_Ford", name: "Bellman-Ford Algorithm", component: BellmanFord },
  { path: "/Floyd_Warshall", name: "Floyd-Warshall Algorithm", component: FloydWarshall },
  { path: "/Prim_MST", name: "Prim's Algorithm", component: PrimMST },
  { path: "/Kruskal_MST", name: "Kruskal's Algorithm", component: KruskalMST },
  { path: "/Ford_Fulkerson", name: "Ford-Fulkerson Method", component: FordFulkerson },
  {path: "/Binary_Search_Answer", name: "Binary Search on Answer", component: BinarySearchAnswer },
  { path: "/Meet_in_the_Middle", name: "Meet in the Middle", component: MeetInTheMiddle },
  { path: "/Bitmask_TSP", name: "Bitmask TSP", component: BitmaskTSP },
  { path: "/Hungarian_Algorithm", name: "Hungarian Algorithm", component: HungarianAlgorithm },
  { path: "/Linear_Programming_2D", name: "Linear Programming 2D", component: LinearProgramming2D },
  { path: "/Genetic_Algorithm", name: "Genetic Algorithm", component: GeneticAlgorithm },

  { path: "/PalindromeCheck", name: "Check Palindrome", component: PalindromeCheck },
  { path: "/Find_Duplicates_in_an_Array", name: "Find Duplicates", component: FindDuplicatesInArray },
  { path: "/Find_Minimum_and_Maximum_in_Array", name: "Min & Max in Array", component: FindMinAndMaxInArray },
  { path: "/Reverse_a_String", name: "Reverse String", component: ReverseAString },
  { path: "/String_Length", name: "String Length", component: StringLength },
  { path: "/Two_Sum_Problem", name: "Two Sum Problem", component: TwoSumProblem },
  { path: "/Remove_Duplicates_For_Sorted_Array", name: "Remove Duplicates", component: RemoveDuplicatesForSortedArray },
  { path: "/Bubble_Sort", name: "Bubble Sort", component: BubbleSort },
  { path: "/Linear_Search", name: "Linear Search", component: LinearSearch },
  { path: "/Simple_Sorting_In_SQL", name: "Sorting in SQL", component: SimpleSortingInSQL },
  { path: "/Filtering_In_MongoDB", name: "Filtering in MongoDB", component: FilteringInMongoDB },
  { path: "/Prime_Number_Check", name: "Prime Number Check", component: PrimeNumberCheck },
  { path: "/CI_CD_Flow", name: "CI/CD Flow", component: CICDFlowDiagram },
];

export default routes;
